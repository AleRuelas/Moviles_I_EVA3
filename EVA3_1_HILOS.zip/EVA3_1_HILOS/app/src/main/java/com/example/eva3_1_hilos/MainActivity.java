package com.example.eva3_1_hilos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    TextView txtVwMensa;
    Thread tMiHilo;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtVwMensa = findViewById(R.id.txtVwMensa);

         tMiHilo = new Thread(){
            @Override
            public void run(){
                super.run();
//Aqui se hace el trabajo en segundo plano
                int i=0;
                while (true){
                    try {
                        Thread.sleep(1000);
                        Log.wtf("hilo","i ="+ i);
                        //txtVwMensa.append("HILO = "+ i);
                        i++;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        Log.wtf("holo interrumpido ", "");
                        break;
                        //Terminamos ejecucion
                    }

                }
            }
        };
        tMiHilo.start();
                            //Clase
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                int i=0;
                while (true){
                    try {
                        Thread.sleep(1000);
                        Log.wtf("Runnable","j ="+ i);

                        //txtVwMensa.append("RUNNEABLE = "+ i);
                        i++;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };

        Thread rHilo = new Thread(runnable);

        rHilo.start();


    }
    @Override
    protected void onStop() {
        super.onStop();
    }
}
