package com.example.eva3_1_hilos;

public class MiHilo extends Thread{


    @Override
    public void run() {
        super.run();

    }
}
