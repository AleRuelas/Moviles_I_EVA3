package com.example.eva3_4_banner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {
    SeekBar barra;
    ImageView iVwBanner;
    int cont = 0;
    Handler handler = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (cont){
                case 0:
                    iVwBanner.setImageResource(R.drawable.light_rain);
                    cont++;
                    break;
                case 1:
                    iVwBanner.setImageResource(R.drawable.rainy);
                    cont++;
                    break;
                case 2:
                    iVwBanner.setImageResource(R.drawable.snow);
                    cont++;
                    break;
                default:
                    iVwBanner.setImageResource(R.drawable.thunderstorm);
                    cont=0;
            }
        }
    };
    Thread tHilo = new Thread(){
        @Override
        public void run() {
            super.run();
            while (true) {
                try {
                    //Thread.sleep(1000);
                    barra.setMax(5000);
                    int cam = barra.getProgress();
                    if (cam ==0){
                        Thread.sleep(1000);
                    } else if (cam==1000){
                        Thread.sleep(50);
                    }else{
                        Thread.sleep(1000-(cam/10));
                    }


                    Message msg = handler.obtainMessage();
                    handler.sendMessage(msg);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }

            }

        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iVwBanner =  findViewById(R.id.iVwBanner);
        barra=findViewById(R.id.seekBar);

        tHilo.start();
        /*
        barra.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar,int progress, boolean fromUser) {
                        stiempo = String.valueOf(progress);
                        txtBarra.setText(stiempo + "");

                    }
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }
                });

         */
    }
}
