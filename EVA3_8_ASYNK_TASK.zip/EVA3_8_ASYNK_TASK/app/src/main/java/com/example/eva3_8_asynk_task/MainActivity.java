package com.example.eva3_8_asynk_task;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txtVw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtVw = findViewById(R.id.txtVw);
        MiClaseAsin miClase = new MiClaseAsin();
        miClase.execute(20,500);
    }
                                        //ENTRADA  PROGRESO  FIN
    class MiClaseAsin extends AsyncTask<Integer,String,String>{
        //TODOS PUEDEN INTERRACTUAR CON LA UI, EXCEPTO EL doInBackground
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            txtVw.setText("INICIO DE LA CLASE ASINCRONA \n");
        }
        //Equivalente del run en thread
        @Override
        protected String doInBackground(Integer... integers) {
            int iVeces = integers[0];
            int iDemora = integers[1];
            for (int i = 0; i < iVeces; i++){
                try {
                    Thread.sleep(iDemora);
                    publishProgress(i + " - ");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            return "FIN DE LA ASYNTASK";

        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
            txtVw.append(values[0]);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            txtVw.append(s);
        }

    }
}
