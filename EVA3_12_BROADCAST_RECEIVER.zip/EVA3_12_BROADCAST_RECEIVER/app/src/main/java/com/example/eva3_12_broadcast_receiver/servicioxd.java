package com.example.eva3_12_broadcast_receiver;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class servicioxd extends Service {
    Thread thilo;
    public servicioxd() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Intent mensaje = new Intent("miservicio");
        mensaje.putExtra("mensaje", "onCreate");
        sendBroadcast(mensaje);
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
        Intent mensaje = new Intent("miservicio");
        mensaje.putExtra("mensaje", "onStart");
        sendBroadcast(mensaje);
        thilo = new Thread(){
            @Override
            public void run() {
                super.run();
                while (true){
                    try {
                        Thread.sleep(2000);
                        Intent mensaje1 = new Intent("miservicio");
                        mensaje1.putExtra("mensaje", "onStartExtra");
                        sendBroadcast(mensaje1);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        break;
                    }
                }
            }
        };
        thilo.start();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Intent mensaje = new Intent("miservicio");
        mensaje.putExtra("mensaje", "onDestroy");
        sendBroadcast(mensaje);
        thilo.interrupt();
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");

    }
}
