package com.example.eva3_5_handler_post;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Handler handler = new Handler();
    //Aqui no se puede modificar la UI, para eso el Runnable
    Thread tHilo = new Thread(){
        @Override
        public void run() {
            super.run();
            //Aqui va el trabajo en segundo plano.
            while (true){
                try {
                    Thread.sleep(500);
                    handler.post(rModificaUI);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    };


    //Aqui si se puede modificar la UI
    Runnable rModificaUI = new Runnable() {
        @Override
        public void run() {
            //Aqui va el trabajo de modificar la UI
            txtV.append("Hola mundo!");
            txtV.append("\n");
        }
    };

    TextView txtV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtV= findViewById(R.id.txtV);
        tHilo.start();
    }
}
