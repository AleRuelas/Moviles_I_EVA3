package com.example.eva3_6_banner_post;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    SeekBar barra;
    ImageView iVwBanner;
    int cont=0;

    Handler handler = new Handler();
    //Aqui no se puede modificar la UI, para eso el Runnable
    Thread tHilo = new Thread(){
        @Override
        public void run() {
            super.run();
            //Aqui va el trabajo en segundo plano.
            while (true){
                try {
                    barra.setMax(5000);
                    int cam = barra.getProgress();
                    if (cam ==0){
                        Thread.sleep(8000);
                    } else if (cam==1000){
                        Thread.sleep(6000);
                    } else if (cam==2000){
                        Thread.sleep(4000);
                    } else if (cam>=5000){
                        Thread.sleep(2000);
                    }else{
                        Thread.sleep(500);
                    }
                    /*Thread.sleep(500);

                     */
                    handler.post(rModificaUI);


                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    };


    //Aqui si se puede modificar la UI
    Runnable rModificaUI = new Runnable() {
        @Override
        public void run() {
            //Aqui va el trabajo de modificar la UI
            switch (cont){
                case 0:
                    iVwBanner.setImageResource(R.drawable.light_rain);
                    cont++;
                    break;
                case 1:
                    iVwBanner.setImageResource(R.drawable.sunny);
                    cont++;
                    break;
                case 2:
                    iVwBanner.setImageResource(R.drawable.snow);
                    cont++;
                    break;
                default:
                    iVwBanner.setImageResource(R.drawable.cloudy);
                    cont=0;
            }
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iVwBanner = findViewById(R.id.iVwBanner);
        barra=findViewById(R.id.seekBar);
        tHilo.start();
    }
}
