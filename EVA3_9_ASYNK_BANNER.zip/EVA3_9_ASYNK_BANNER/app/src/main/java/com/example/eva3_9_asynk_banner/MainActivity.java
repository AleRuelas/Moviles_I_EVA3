package com.example.eva3_9_asynk_banner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Message;
import android.widget.ImageView;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    SeekBar barra;
    ImageView iVwBanner;
    int progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iVwBanner =  findViewById(R.id.iVwBanner);
        barra=findViewById(R.id.seekBar);
        barra.setMax(10000);
        MiClaseAsin miClase = new MiClaseAsin();
        miClase.execute();
    }

    class MiClaseAsin extends AsyncTask<Void,Integer,Void> {
        //TODOS PUEDEN INTERRACTUAR CON LA UI, EXCEPTO EL doInBackground
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progress = barra.getProgress();
        }
        //Equivalente del run en thread
        @Override
        protected Void doInBackground(Void... integers) {
            for (int i = 0; i<4; i++) {
                try {
                    //Thread.sleep(1000);
                    if (progress == 0) {
                        Thread.sleep(1000);
                    } else if (progress==10000){
                        Thread.sleep(50);
                    }else{
                        Thread.sleep(1000-(progress/10));
                    }
                    publishProgress(i);
                    if(i==3){
                        i=0;
                    }
                }catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
            return null;

        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progress=barra.getProgress();
            switch (values[0]){
                case 0:
                    iVwBanner.setImageResource(R.drawable.light_rain);
                    break;
                case 1:
                    iVwBanner.setImageResource(R.drawable.rainy);
                    break;
                case 2:
                    iVwBanner.setImageResource(R.drawable.snow);
                    break;
                default:
                    iVwBanner.setImageResource(R.drawable.sunny);

            }
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

}
