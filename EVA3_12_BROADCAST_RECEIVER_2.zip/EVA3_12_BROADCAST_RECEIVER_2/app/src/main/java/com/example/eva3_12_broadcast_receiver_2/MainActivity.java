package com.example.eva3_12_broadcast_receiver_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txt;
    BroadcastReceiver br;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt = findViewById(R.id.txt1);
        //inServicio = new Intent(this, servicioxd.class);
        br = new MiBR();
        IntentFilter filtro = new IntentFilter("miservicio");
        registerReceiver(br, filtro);
    }

    class MiBR extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
            txt.append(intent.getStringExtra("mensaje") + "\n");
        }
    }
}
