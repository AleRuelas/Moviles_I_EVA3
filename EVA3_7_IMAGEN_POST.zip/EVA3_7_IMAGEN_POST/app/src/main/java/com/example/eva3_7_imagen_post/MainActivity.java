package com.example.eva3_7_imagen_post;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    Bitmap imagen = null;
    ImageView imaMostrar;

    Handler handler = new Handler();

    Thread hilo = new Thread(){
        @Override
        public void run() {
            super.run();

                    imagen = cargarImagen("https://image.freepik.com/vector-gratis/fondo-pantalla-patron-dinamico-abstracto_53876-62605.jpg");
                    handler.post(rModificaUI);



        }
    };
    //Aqui si se puede modificar la UI
    Runnable rModificaUI = new Runnable() {
        @Override
        public void run() {
            //Aqui va el trabajo de modificar la UI
            imaMostrar.setImageBitmap(imagen);

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imaMostrar = findViewById(R.id.imaMostrar);
        hilo.start();
    }

    //Metodo para procesar la imagen
    private Bitmap cargarImagen(String url){
        Bitmap imagen = null;

        try {
            InputStream input = (InputStream) new URL(url).getContent();
            imagen = BitmapFactory.decodeStream(input);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imagen;
    }


}
