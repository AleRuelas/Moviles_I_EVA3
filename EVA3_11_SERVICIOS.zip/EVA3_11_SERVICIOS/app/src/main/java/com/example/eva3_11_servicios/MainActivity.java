package com.example.eva3_11_servicios;

/*
Service --> Similar a la actividad
            Ejecutan tareas en segundo plano
            A diferencia de los hilos, estos envian datos
            Una actividad sin interfaz
            Servicio para varias apps
            Las apps escuchan al servicio
            Tiene su ciclo de vida, mas reducido a una actividad

            El servicio solo se crea una vez

 */

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Intent inServicio;
    TextView txtVDatos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtVDatos= findViewById(R.id.txtV);
        inServicio = new Intent(this, MyService.class);


    }
    public void inServicio (View view){
        startService(inServicio);
    }
    public void stoServicio (View view){
        stopService(inServicio);
    }




}
